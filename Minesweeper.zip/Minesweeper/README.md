# Compilation
Pour compiler l'application:
Se placer dans le dossier "src" et exécuter la commande:
javac minesweeper/*.java -d ../build/

# Execution
Se placer dans le dossir "build" et exécuter la commande:
java minesweeper.Minesweeper